# Exercícios

Imagine um sistema voltado para a organização de campeonatos de futebol amador e profissional. Ele permitirá que administradores e equipes cadastrem campeonatos, partidas e jogadores, além de gerenciar partidas, resultados e estatísticas. O objetivo principal é facilitar a gestão do torneio e fornecer informações precisas para os envolvidos.

Utilizando o typescript, HTML e Localstorage crie: 

Exercício 1 - Cadastro de campeonato

Criar um novo campeonato informando nome, categoria (amador, profissional), tipo de torneio (mata-mata, pontos corridos), data de início e término.

Exercício 2 - Cadastro de partida 

Criar um cadastro de partida, cada partida terá, time mandante e visitante (pode ser caracter, não precisa criar o cadastro de time. Também será necessário amarrar a um campeonato

Exercício 3 - Cadastro de time 

Criar um cadastro de time informando nome e nome curto (exemplo: SAO, COR, FLU, etc). 
